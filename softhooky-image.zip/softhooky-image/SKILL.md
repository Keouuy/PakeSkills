---
name: softhooky-image
description: 生成图片或编辑图片。先判断用户积分是否足够，生成/编辑完成后扣除积分。使用此skill当用户想要生成新图片或编辑已有图片。
---

# Softhooky Image

在softhooky.com网站上生成图片或编辑图片。调用现有项目的生图/编辑图片API，执行完成后扣除对应积分。

## 用户配置

首次使用前需要配置用户账号信息：

```bash
python3 scripts/config.py set username <邮箱>
python3 scripts/config.py set password <密码>
```

查看当前配置：

```bash
python3 scripts/config.py show
```

## 命令

| 命令 | 参数 | 说明 |
|------|------|------|
| `generate` | `<prompt> [model] [aspect_ratio] [resolution]` | 文生图，根据描述生成图片 |
| `edit` | `<prompt> <image_url> [model]` | 图生图/编辑图片 |
| `credits` | - | 查看当前积分 |
| `login` | - | 登录并验证账号 |

## 使用示例

生成图片：
```bash
python3 scripts/softhooky.py generate "一只可爱的猫咪坐在窗台上" 
python3 scripts/softhooky.py generate "美食摄影 product" "gemini-3.1-flash-image-preview" "16:9" "1K"
```

编辑图片：
```bash
python3 scripts/softhooky.py edit "添加一些装饰元素" "https://example.com/image.jpg"
python3 scripts/softhooky.py edit "换成夜景" "https://example.com/photo.jpg" "gemini-2.0-flash-exp"
```

查看积分：
```bash
python3 scripts/softhooky.py credits
```

## 积分规则

- 生图：每次 0.3 积分
- 编辑：每次 0.3 积分
- 视频：每次 0.5 积分

## 输出格式

生成成功返回图片URL：
```
SUCCESS: https://softhooky.com/images/xxx.jpg
Remaining credits: X.X
```

积分不足时：
```
ERROR: 积分不足，需要 0.3 积分，当前仅有 X.X 积分
```

## 注意事项

- 首次使用需先配置账号密码
- 每次生成/编辑前会先检查积分，积分足够才会执行
- 成功执行后自动扣除积分
- API地址已配置为 https://softhooky.com