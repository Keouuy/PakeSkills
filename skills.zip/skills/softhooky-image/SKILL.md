---
name: softhooky-image
description: 生成图片或编辑图片。先判断用户积分是否足够，生成/编辑完成后扣除积分。使用此skill当用户想要生成新图片或编辑已有图片。
---

# Softhooky Image

在softhooky.com网站上生成图片或编辑图片。调用现有项目的生图/编辑图片API，执行完成后扣除对应积分。

## 用户配置

首次使用前需要配置用户账号信息：

```bash
python3 scripts/config.py set username <邮箱>
python3 scripts/config.py set password <密码>
```

查看当前配置：

```bash
python3 scripts/config.py show
```

## 命令

| 命令 | 参数 | 说明 |
|------|------|------|
| `generate` | `<prompt> [model] [aspect_ratio] [resolution]` | 文生图，根据描述生成图片 |
| `edit` | `<prompt> <image_path_or_url> [model] [aspect_ratio] [resolution]` | 图生图/编辑图片，支持本地图片路径或URL |
| `credits` | - | 查看当前积分 |
| `login` | - | 登录并验证账号 |

### 模型

| 模型 | 说明 | aspect_ratio 可选值 | resolution |
|------|------|---------------------|------------|
| `gpt-image-2` (默认) | GPT-Image2 生图引擎，默认 auto 自动比例 | `auto`, `1024x1024`, `1536x1024`, `1024x1536`, `2048x1152`, `2160x3840`, `3840x2160` | 不适用 |
| `gemini-3.1-flash-image-preview` | Nanobann2 生图引擎 | `智能`, `1:1`, `3:4`, `16:9`, `9:16`, `21:9` | `1K`, `2K`, `4K` |

## 使用示例

生成图片：
```bash
python3 scripts/softhooky.py generate "一只可爱的猫咪坐在窗台上"          # 默认 gpt-image-2, auto 比例
python3 scripts/softhooky.py generate "美食摄影" gemini-3.1-flash-image-preview "16:9" "4K"
python3 scripts/softhooky.py generate "电商产品图 白色背景" gpt-image-2 "1024x1024"
```

编辑图片（支持本地图片路径或URL）：
```bash
python3 scripts/softhooky.py edit "添加一些装饰元素" "C:\图片\product.jpg"  # 本地图片自动转base64
python3 scripts/softhooky.py edit "换成夜景" "https://example.com/photo.jpg" "gemini-3.1-flash-image-preview"
python3 scripts/softhooky.py edit "把背景换成白色" "C:\photo.png" "gpt-image-2"
```

查看积分：
```bash
python3 scripts/softhooky.py credits
```

## 积分规则

积分价格从服务器 `/api/pricing` 动态获取，跟随后台定价，无需硬编码。当前典型价格：

- 生图 (gemini-3.1-flash-image-preview)：每次 0.3 积分
- 生图 (gpt-image-2)：每次 0.3 积分
- 编辑：每次 0.3 积分
- 视频：每次 0.5 积分

## 输出格式

生成成功返回图片URL：
```
SUCCESS: https://softhooky.com/images/xxx.jpg
Remaining credits: X.X
```

积分不足时：
```
ERROR: 积分不足，需要 0.3 积分，当前仅有 X.X 积分
```

## 注意事项

- 首次使用需先配置账号密码
- 每次生成/编辑前会先检查积分，积分足够才会执行
- 成功执行后自动扣除积分
- API地址已配置为 https://softhooky.com
- 默认模型为 `gpt-image-2`，aspect_ratio 默认 `auto`（API自动决定最佳比例），用户无需关心比例
- gpt-image-2 的 aspect_ratio 可选像素尺寸（如 `1024x1024`），不支持 resolution 参数
- gemini-3.1-flash-image-preview 的 aspect_ratio 使用比例（如 `16:9`），支持 resolution（默认 `2K`）
- **编辑图片**：支持本地文件路径或URL，本地文件自动转为base64上传到API；编辑也支持 aspect_ratio 和 resolution 参数
- **积分价格**：动态从 `/api/pricing` 获取，60秒缓存，跟随后台定价
- **Token 复用**：已登录的 token 会自动复用，过期后才重新登录，避免频繁请求
- **生成结果**：后端自动将图片保存到 Cloudflare R2，返回永久可访问的URL