#!/usr/bin/env python3
import os
import sys
import json
import base64
import time
import requests
from pathlib import Path

CONFIG_FILE = Path(__file__).parent / "config.json"
API_BASE = "https://softhooky.com/api"

def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {}

def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

def validate_token(token):
    try:
        resp = requests.get(f"{API_BASE}/auth/credits", headers={"Authorization": f"Bearer {token}"}, timeout=10)
        return resp.status_code == 200
    except:
        return False

def get_token():
    config = load_config()

    if config.get("token") and validate_token(config["token"]):
        return config["token"]

    if not config.get("username") or not config.get("password"):
        print("ERROR: 请先配置账号密码")
        print("运行: python3 config.py set username <邮箱>")
        print("运行: python3 config.py set password <密码>")
        return None

    try:
        response = requests.post(
            f"{API_BASE}/auth/login",
            json={"email": config["username"], "password": config["password"]},
            timeout=30
        )
        data = response.json()
        if data.get("success"):
            config["token"] = data.get("token")
            config["credits"] = data.get("user", {}).get("credits", 0)
            save_config(config)
            return data.get("token")
        else:
            print(f"ERROR: 登录失败 - {data.get('message')}")
            return None
    except Exception as e:
        print(f"ERROR: 登录失败 - {str(e)}")
        return None

def get_credits(token):
    try:
        response = requests.get(
            f"{API_BASE}/auth/credits",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10
        )
        data = response.json()
        return data.get("credits", 0)
    except Exception as e:
        print(f"ERROR: 获取积分失败 - {str(e)}")
        return 0

def ensure_credits(model, action="generate", action_label=""):
    token = get_token()
    if not token:
        return None

    cost = get_cost(model, action)

    print("检查积分...")
    credits = get_credits(token)
    print(f"当前积分: {credits}")

    if credits < cost:
        print(f"ERROR: 积分不足，需要 {cost} 积分，当前仅有 {credits} 积分")
        return None

    if action_label:
        print(f"积分充足，开始{action_label}...")
    return token

def call_api(endpoint, token, json_data, action_label):
    try:
        response = requests.post(
            f"{API_BASE}/{endpoint}",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            json=json_data,
            timeout=300
        )

        if response.status_code == 400:
            error_data = response.json()
            if "积分" in error_data.get("error", ""):
                print(f"ERROR: {error_data.get('error')}")
                return
            raise Exception(error_data.get("error"))

        data = response.json()

        if data.get("data") and len(data["data"]) > 0:
            image_url = data["data"][0].get("url")
            remaining = data.get("remainingCredits", 0)
            print(f"SUCCESS: {image_url}")
            print(f"Remaining credits: {remaining}")
        else:
            print(f"ERROR: {action_label}失败 - {data}")
    except Exception as e:
        print(f"ERROR: {action_label}失败 - {str(e)}")

def is_gpt_image2(model):
    return model and model.lower() in ("gpt-image-2", "gpt_image2")

PRICING_CACHE = None
PRICING_CACHE_TIME = 0
PRICING_CACHE_TTL = 60000

def fetch_pricing():
    global PRICING_CACHE, PRICING_CACHE_TIME
    now = time.time() * 1000
    if PRICING_CACHE and now - PRICING_CACHE_TIME < PRICING_CACHE_TTL:
        return PRICING_CACHE

    token = load_config().get("token")
    if not token:
        return None
    try:
        resp = requests.get(f"{API_BASE}/pricing", headers={"Authorization": f"Bearer {token}"}, timeout=10)
        data = resp.json()
        if data.get("success"):
            PRICING_CACHE = data.get("data", {})
            PRICING_CACHE_TIME = now
            return PRICING_CACHE
    except:
        pass
    return None

def get_cost(model, action="generate"):
    pricing = fetch_pricing()
    fallback = 0.3
    if not pricing:
        return fallback
    key = f"{'gpt_image2' if is_gpt_image2(model) else 'nanobann2'}_{action}"
    return pricing.get(key, fallback)

MIME_MAP = {
    '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
    '.png': 'image/png', '.gif': 'image/gif',
    '.webp': 'image/webp', '.bmp': 'image/bmp',
}

def resolve_image_source(path_or_url):
    p = Path(path_or_url)
    if p.exists():
        suffix = p.suffix.lower()
        mime = MIME_MAP.get(suffix, 'image/png')
        with open(p, 'rb') as f:
            b64 = base64.b64encode(f.read()).decode('utf-8')
        print(f"读取本地图片: {p.name} ({mime})")
        return f"data:{mime};base64,{b64}"
    return path_or_url

def generate_image(prompt, model="gpt-image-2", aspect_ratio=None, resolution=None):
    is_gpt2 = is_gpt_image2(model)

    if aspect_ratio is None:
        aspect_ratio = "auto" if is_gpt2 else "智能"
    if resolution is None and not is_gpt2:
        resolution = "2K"

    token = ensure_credits(model, "generate", "生成图片")
    if not token:
        return

    print(f"Prompt: {prompt}")
    print(f"Model: {model}, Aspect: {aspect_ratio}", end="")
    if not is_gpt2 and resolution:
        print(f", Resolution: {resolution}")
    else:
        print()

    payload = {
        "prompt": prompt,
        "model": model,
        "aspectRatio": aspect_ratio,
    }
    if not is_gpt2 and resolution:
        payload["resolution"] = resolution

    call_api("images/generations", token, payload, "生成")

def edit_image(prompt, image_source, model="gpt-image-2", aspect_ratio=None, resolution=None):
    is_gpt2 = is_gpt_image2(model)

    if aspect_ratio is None:
        aspect_ratio = "auto" if is_gpt2 else "智能"

    token = ensure_credits(model, "edit", "编辑图片")
    if not token:
        return

    image_data = resolve_image_source(image_source)
    print(f"Prompt: {prompt}")
    print(f"Model: {model}, Aspect: {aspect_ratio}", end="")
    if not is_gpt2 and resolution:
        print(f", Resolution: {resolution}")
    else:
        print()

    payload = {
        "prompt": prompt,
        "images": [image_data],
        "model": model,
        "aspectRatio": aspect_ratio,
    }
    if resolution:
        payload["size"] = resolution

    call_api("images/edits", token, payload, "编辑")

def show_credits():
    token = get_token()
    if not token:
        return
    
    credits = get_credits(token)
    print(f"当前积分: {credits}")

def main():
    if len(sys.argv) < 2:
        print("""
Softhooky 图片生成工具

用法:
    python3 softhooky.py generate <prompt> [model] [aspect_ratio] [resolution]
    python3 softhooky.py edit <prompt> <image_path_or_url> [model] [aspect_ratio] [resolution]
    python3 softhooky.py credits
    python3 softhooky.py config show
    python3 softhooky.py config set username <邮箱>
    python3 softhooky.py config set password <密码>

模型:
    gpt-image-2  (默认)  — 支持 size(auto,1024x1024,1536x1024,1024x1536,2048x1152,2160x3840,3840x2160)
    gemini-3.1-flash-image-preview  — 支持 ratio(智能,1:1,3:4,16:9,9:16,21:9) + resolution(1K,2K,4K)

提示:
    image_path_or_url 支持本地图片路径或URL，本地图片自动转base64上传
    不指定 aspect_ratio 时默认 auto（由API自动决定最佳比例）
    积分价格从服务器动态获取，跟随后台定价

示例:
    python3 softhooky.py generate "一只可爱的猫咪"
    python3 softhooky.py generate "产品摄影" gemini-3.1-flash-image-preview "16:9" "4K"
    python3 softhooky.py edit "添加装饰" "C:\\image.jpg"
    python3 softhooky.py edit "换背景" "https://example.com/img.jpg" gpt-image-2 auto
    python3 softhooky.py credits
        """)
        sys.exit(1)
    
    cmd = sys.argv[1]
    
    if cmd == "config":
        from config import main as config_main
        config_main()
    elif cmd == "generate":
        if len(sys.argv) < 3:
            print("ERROR: 请提供prompt")
            sys.exit(1)
        prompt = sys.argv[2]
        model = sys.argv[3] if len(sys.argv) > 3 else "gpt-image-2"
        aspect = sys.argv[4] if len(sys.argv) > 4 else None
        resolution = sys.argv[5] if len(sys.argv) > 5 else None
        generate_image(prompt, model, aspect, resolution)
    elif cmd == "edit":
        if len(sys.argv) < 4:
            print("ERROR: 请提供prompt和图片路径或URL")
            sys.exit(1)
        prompt = sys.argv[2]
        image_source = sys.argv[3]
        model = sys.argv[4] if len(sys.argv) > 4 else "gpt-image-2"
        aspect = sys.argv[5] if len(sys.argv) > 5 else None
        resolution = sys.argv[6] if len(sys.argv) > 6 else None
        edit_image(prompt, image_source, model, aspect, resolution)
    elif cmd == "credits":
        show_credits()
    elif cmd == "login":
        token = get_token()
        if token:
            print("登录成功!")
    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)

if __name__ == "__main__":
    main()